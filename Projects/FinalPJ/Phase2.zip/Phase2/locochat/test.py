# from connect import get_db
# from store import store
# #
# # shared = store()
# # shared.count = 1
# #
# # shared2 = store()
# # # shared2.count = 23
# # # # print(shared.count)
# # # with open("cli_assets/welcome.txt") as file:
# # #     for line in file:
# # #         print(line.rstrip())
# # #
# # test = "9931Abc#099"
# # res = test.isdigit()
# # print(res)
# # import re
# #
# # name = 2
# # def age():
# #     return name+3
# # print(age())
# # print(shared2.error_message)
# import mysql.connector as connector
#
# NAME = "locochat"
#
# #
# # def get_db():
# #     db = connector.connect(
# #         host="localhost",
# #         user="root",
# #         passwd="DbMYSQL2003",
# #         database=NAME
# #     )
# #     return db
# #
# #
# # db = get_db()
# # cursor = db.cursor()
# # username = "amirfazel22"
# # usernames = []
# # usernames.append(username)
# #
# # query = " select userID from users"
# # userIDs = ("amirfaze21","amirfazel22","amirfazel23")
# # print(username in userIDs)
# #
# # cursor.execute(query)
# # print(cursor.rowcount == 0)
# # res = cursor.fetchall()
# # print(type(res))
# # for row in res:
# #     print(row)
# import secrets
# # t = secrets.token_hex(25)
# # print(t)
# # t = secrets.token_hex(25)
# # print(len(t))
# # from hashlib import sha256
# #
# # user = {
# #     "username": input('username: '),
# #     "password": input('password: '),
# #     "first_name": input('first_name: '),
# #     "last_name": input('last_name: '),
# #     "phone_number": input('phone_number: '),
# #     "email": input('email: '),
# #     "security_question_answer": input('fav color: ')
# # }
# # token = secrets.token_hex(25)
# # sql = """
# #         insert into `users`
# #         (token, userID, first_name, last_name, phone_number, email, password_hashed, security_question_answer)
# #         VALUES
# #         (%s, %s, %s, %s, %s, %s, %s, %s)
# #         """
# # val = (token, user['username'], user["first_name"], user["last_name"], user["phone_number"], user["email"],
# #        sha256(user["password"].encode('utf-8')).hexdigest(), user["security_question_answer"])
# #
# # try:
# #     cursor.execute(sql, val)
# #     db.commit()
# #     print("added to db")
# #
# # except Exception as inst:
# #     print("not added")
# #     print(inst)
# #     db.rollback()
#
# from connect import *
#
# db = get_db()
# cursor = db.cursor()
#
#
#
# # sql = """
# #     select count(entered_user_ID), entered_user_ID
# #     from `logins`
# #     where login_situation = '1'
# #     """
# #
# # try:
# #         cursor.execute(sql)
# #         res = cursor.fetchall()
# #         print(res)
# #         count = res[0][0]
# #         username = res[0][1]
# #         print(username)
# #         user = {"username": username}
# #         db.commit()
# #
# # except Exception as inst:
# #         print(inst)
# #         db.rollback()
# smp = 'hi there'.split(' ')
# print(smp[0])
# print(smp[1])
import getpass

# password = getpass.getpass(prompt='please enter your password: ')
# smp = "hi".split(' ')
# print(smp[1] == '')
# tkn = 'aaaa'
# name ='abc'
# age = 12
# person = {tkn,name, age}
# print()
# splitt = 'hi I am fazel'.split(' ')
# print(splitt)
# tmp = splitt[1:]
# # string = ' '.join([str(item) for item in tmp])
# # print(string)
# cmd = 'msg'
# print(cmd == 'msg')
# print(cmd != 'cfd')
# print(not cmd == 'cfd')
#
# arr = [('hi',), ('ay',), ('yo',)]
# srm = ','.join(str(i[0]) for i in arr)
# print(srm)
# test = ''
# test2 = '            '
# print(len(test))
# print(len(test2))
# print(len(test.rstrip()))
# print(len(test2.rstrip()))
#
# from connect import *
# db = get_db()
# cursor = db.cursor()
# sql = """
#         select userID
#         from `users`
#         where token = %s
#         """
# token = '533aa8e389352d70060d58baa7055c0941447b5eac0be82890'
# val = (token,)
#
# try:
#         cursor.execute(sql, val)
#         res = cursor.fetchall()
#         print(res)
#         if len(res) == 0:
#             print('arrrrrrrrrr')
#             username = None
#         else:
#             username = res[0][0]
#         user = {
#             "token": token,
#             "username": username
#         }
#
#         print(user)
#         db.commit()
#
# except Exception as inst:
#         print(inst)
#         db.rollback()

import time
import datetime

ts = time.time()
timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
ftr = datetime.datetime.fromtimestamp(ts) + datetime.timedelta(days=5)
future = ftr.strftime('%Y-%m-%d %H:%M:%S')
print(future)
print(timestamp)


current_datetime = datetime.datetime.utcnow()

future_datetime = current_datetime + datetime.timedelta(minutes=5)
# future_datetime = future_datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
print(timestamp < future)
# user = {
#     "ID": 'pepoo'
# }
# print(user["ID"])
# print(user[0])
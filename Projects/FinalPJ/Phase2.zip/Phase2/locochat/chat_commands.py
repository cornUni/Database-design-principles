class ChatCommands:
    LIKE = 'like'
    SEND = 'send'
    CLOSE = 'close'
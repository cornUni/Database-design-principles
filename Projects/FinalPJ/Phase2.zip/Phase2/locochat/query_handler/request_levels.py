class RequestLevels:
    ACCEPTED = 'accepted'
    REJECTED = 'rejected'
    PENDING = 'pending'
